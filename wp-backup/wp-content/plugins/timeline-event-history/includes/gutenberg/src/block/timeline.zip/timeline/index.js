/**
 * BLOCK: Shortcode
 *
 * Registering a basic block with Gutenberg.
 * Simple block, renders and saves the same content without any interactivity.
 */

//  Import CSS.
import './style.scss';
import './editor.scss';
import { icon } from '../../icons'
import times from "lodash/times"
import classnames from "classnames"
import TimelineIcons from "../../../dist/blocks/controls/Icons.json"
import FontIconPicker from "@fonticonpicker/react-fonticonpicker"
import renderSVG from "../../../dist/blocks/controls/renderIcon"
import attributes from "./attributes"
import TmClasses from "./classes"
const { apiFetch } = wp;
const { decodeEntities } = wp.htmlEntities
import TypographyControl from "../../components/typography"
import {
	registerBlockType,
	__,
	PanelBody,	
	Button,
	ColorPalette,
	SelectControl,	
	TextControl,	
	TabPanel,
	ToggleControl,
	PanelColorSettings,
	InspectorControls,	
	RangeControl,	
	MediaUpload,
	Fragment,
} from '../../wp-imports'

const {
	withSelect
} = wp.data

let svg_icons = Object.keys( TimelineIcons )


export const edit = ( props ) => {
	// Setup the attributes.
	const { className, setAttributes, insertBlocksAfter, mergeBlocks, onReplace, attributes: { tm_content, design, headingAlign, separatorHeight, headSpace, separatorSpace, headingColor, subHeadingColor, backgroundColor, separatorColor, separatorFillColor, separatorBg, separatorBorder, borderFocus, headingTag, headFontSizeType, headFontSize, headFontSizeTablet, headFontSizeMobile, headFontFamily, headFontWeight, headFontSubset, headLineHeightType, headLineHeight, headLineHeightTablet, headLineHeightMobile, headLoadGoogleFonts, timelineItem, timelinAlignment, arrowlinAlignment, subHeadFontSizeType, subHeadFontSize, subHeadFontSizeTablet, subHeadFontSizeMobile, subHeadFontFamily, subHeadFontWeight, subHeadFontSubset, subHeadLineHeightType, subHeadLineHeight, subHeadLineHeightTablet, subHeadLineHeightMobile, subHeadLoadGoogleFonts, verticalSpace, horizontalSpace, separatorwidth, borderwidth, connectorBgsize, dateBottomspace, align, icon, iconColor, dateColor, dateFontsizeType, dateFontsize, dateFontsizeTablet, dateFontsizeMobile, dateFontFamily, dateFontWeight, dateFontSubset, dateLineHeightType, dateLineHeight, dateLineHeightTablet, dateLineHeightMobile, dateLoadGoogleFonts, iconSize, borderRadius, bgPadding, block_id, iconFocus, iconBgFocus, t_date, displayPostDate, stack }, } = props
	
	
	
	const saveTimeline = (  value, index ) => {
	
		const newItems = t_date.map( ( item, thisIndex ) => {
			if ( index === thisIndex ) {
				item = { ...item, ...value }
			}
	
			return item
		} )
	
		setAttributes( {
			t_date: newItems,
		} )
	}

	const timelineControls = ( index ) => {

		let timeline_control = ""
		let timeline_control_hover = ""

		if ( "image" == t_date[ index ].image_icon ) {

			timeline_control = (
				<Fragment>
					<p className="uagb-setting-label">{ __( "Text Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].label_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].label_color }
						onChange={ ( value ) => saveTimeline( { label_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Image Background Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_bg_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_bg_color }
						onChange={ ( value ) => saveTimeline( { icon_bg_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Image Border Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_border_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_border_color }
						onChange={ ( value ) => saveTimeline( { icon_border_color: value }, index ) }
						allowReset
					/>
				</Fragment>
			)
			timeline_control_hover = (
				<Fragment>
					<p className="uagb-setting-label">{ __( "Text Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].label_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].label_hover_color }
						onChange={ ( value ) => saveTimeline( { label_hover_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Image Background Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_bg_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_bg_hover_color }
						onChange={ ( value ) => saveTimeline( { icon_bg_hover_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Image Border Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_border_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_border_hover_color }
						onChange={ ( value ) => saveTimeline( { icon_border_hover_color: value }, index ) }
						allowReset
					/>
				</Fragment>
			)
		} else {

			timeline_control = (
				<Fragment>
					<p className="uagb-setting-label">{ __( "Text Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].label_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].label_color }
						onChange={ ( value ) => saveTimeline( { label_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Icon Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_color }
						onChange={ ( value ) => saveTimeline( { icon_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Icon Background Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_bg_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_bg_color }
						onChange={ ( value ) => saveTimeline( { icon_bg_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Icon Border Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_border_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_border_color }
						onChange={ ( value ) => saveTimeline( { icon_border_color: value }, index ) }
						allowReset
					/>
				</Fragment>
			)
			timeline_control_hover = (
				<Fragment>
					<p className="uagb-setting-label">{ __( "Text Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].label_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].label_hover_color }
						onChange={ ( value ) => saveTimeline( { label_hover_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Icon Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_hover_color }
						onChange={ ( value ) => saveTimeline( { icon_hover_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Icon Background Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_bg_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_bg_hover_color }
						onChange={ ( value ) => saveTimeline( { icon_bg_hover_color: value }, index ) }
						allowReset
					/>
					<p className="uagb-setting-label">{ __( "Icon Border Hover Color" ) }<span className="components-base-control__label"><span className="component-color-indicator" style={{ backgroundColor: t_date[ index ].icon_border_hover_color }} ></span></span></p>
					<ColorPalette
						value={ t_date[ index ].icon_border_hover_color }
						onChange={ ( value ) => saveTimeline( { icon_border_hover_color: value }, index ) }
						allowReset
					/>
				</Fragment>
			)
		}

		return (
			<PanelBody key={index}
				title={ __( "Timeline " ) + " " + ( index + 1 ) + " " + __( "Settings" ) }
				initialOpen={ false }
			>
				<SelectControl
					label={ __( "Image / Icon" ) }
					value={ t_date[ index ].image_icon }
					options={ [
						{ value: "icon", label: __( "Icon" ) },
						{ value: "image", label: __( "Image" ) },
					] }
					onChange={ value => {
						saveTimeline( { image_icon: value }, index )
					} }
				/>
				{ "icon" == t_date[ index ].image_icon &&
					<Fragment>
						<p className="components-base-control__label">{__( "Icon" )}</p>
						<FontIconPicker
							icons={svg_icons}
							renderFunc= {renderSVG}
							theme="default"
							value={t_date[ index ].icon}
							onChange={ value => {
								saveTimeline( { icon: value }, index )
							} }
							isMulti={false}
							noSelectedPlaceholder= { __( "Select Icon" ) }
						/>
					</Fragment>
				}
				{ "image" == t_date[ index ].image_icon &&
					<Fragment>
						<MediaUpload
							title={ __( "Select Image" ) }
							onSelect={ value => {
								saveTimeline( { image: value }, index )
							} }
							allowedTypes={ [ "image" ] }
							value={ t_date[ index ].image }
							render={ ( { open } ) => (
								<Button isDefault onClick={ open }>
									{ ! t_date[ index ].image ? __( "Select Image" ) : __( "Replace image" ) }
								</Button>
							) }
						/>
						{ t_date[ index ].image &&
							<Button
								className="uagb-rm-btn"
								onClick={ value => {
									saveTimeline( { image: null }, index )
								} }
								isLink isDestructive>
								{ __( "Remove Image" ) }
							</Button>
						}
					</Fragment>
				}
				<hr className="uagb-editor__separator" />
				<h2>{ __( "List Item Link" ) }</h2>
				<ToggleControl
					label={ __( "Disable Link" ) }
					checked={ t_date[ index ].disableLink }
					onChange={ value => {
						saveTimeline( { disableLink: value }, index )
					} }
				/>
				{ ! t_date[ index ].disableLink &&
					<Fragment>
						<p className="components-base-control__label">{__( "URL" )}</p>
						<TextControl
							value={ t_date[ index ].link }
							onChange={ value => {
								saveTimeline( { link: value }, index )
							} }
							placeholder={__( "Enter URL" )}
						/>
						<ToggleControl
							label={ __( "Open in New Tab" ) }
							checked={ t_date[ index ].target }
							onChange={ value => {
								saveTimeline( { target: value }, index )
							} }
						/>
					</Fragment>
				}
				<hr className="uagb-editor__separator" />
				<h2>{ __( "Icon #" ) + " " + ( index + 1 ) + " " + __( " Color Settings" ) }</h2>
				<TabPanel className="uagb-inspect-tabs uagb-inspect-tabs-col-2"
					activeClass="active-tab"
					tabs={ [
						{
							name: "normal",
							title: __( "Normal" ),
							className: "uagb-normal-tab",
						},
						{
							name: "hover",
							title: __( "Hover" ),
							className: "uagb-hover-tab",
						},
					] }>
					{
						( tabName ) => {
							let color_tab
							if( "normal" === tabName.name ) {
								color_tab = timeline_control
							}else {
								color_tab = timeline_control_hover
							}
							return <div>{ color_tab }</div>
						}
					}
				</TabPanel>
			</PanelBody>
		)
	}
	/* Render output at backend */

	const content_control = (
		<InspectorControls>
			<PanelBody	title={ __( "General / Design" ) }	initialOpen={ true } >
				<RangeControl
					label={ __( "Number of Items" ) }
					value={ timelineItem }
					onChange={ ( newCount ) => {
						let cloneDate = [ ...t_date ]
						let cloneContent = [ ...tm_content ]
						if ( cloneDate.length < newCount ) {
							const incAmount = Math.abs( newCount - cloneDate.length )
							// Save date.
							{ times( incAmount, n => {
								cloneDate.push( {
									title: cloneDate[ 0 ].title,
								} )
							} ) }
							setAttributes( { t_date: cloneDate } )
							//Save content
							{ times( incAmount, n => {
								cloneContent.push( {
									time_heading: __( "Timeline Heading " ) + ( cloneContent.length + 1 ),
									time_desc: cloneContent[ 0 ].time_desc,
								} )
							} ) }
							setAttributes( { tm_content: cloneContent } )
						}
						setAttributes( { timelineItem: newCount } )
					} }
					min={ 1 }
					max={ 20 }
					allowReset
				/>
				<SelectControl
					label={ __( "Design" ) }
					value={ design  }
					onChange={ ( value ) => setAttributes( { design : value } ) }
					options={ [
						{ value: "default", label: __( "Default" ) },
						{ value: "designe-2", label: __( "Another" ) },
					] }
				/>
			</PanelBody>
			{ times( timelineItem, n => timelineControls( n ) ) }
			<PanelBody	title={ __( "Timeline Design And Typography" ) }	initialOpen={ false } >
				<TypographyControl
					label={ __( " Heading Typography" ) }
					attributes = { props.attributes }
					setAttributes = { setAttributes }
					loadGoogleFonts = { { value: headLoadGoogleFonts, label: __( "headLoadGoogleFonts" ) } }
					fontFamily = { { value: headFontFamily, label: __( "headFontFamily" ) } }
					fontWeight = { { value: headFontWeight, label: __( "headFontWeight" ) } }
					fontSubset = { { value: headFontSubset, label: __( "headFontSubset" ) } }
					fontSizeType = { { value: headFontSizeType, label: __( "headFontSizeType" ) } }
					fontSize = { { value: headFontSize, label: __( "headFontSize" ) } }
					fontSizeMobile = { { value: headFontSizeMobile, label: __( "headFontSizeMobile" ) } }
					fontSizeTablet= { { value: headFontSizeTablet, label: __( "headFontSizeTablet" ) } }
					lineHeightType = { { value: headLineHeightType, label: __( "headLineHeightType" ) } }
					lineHeight = { { value: headLineHeight, label: __( "headLineHeight" ) } }
					lineHeightMobile = { { value: headLineHeightMobile, label: __( "headLineHeightMobile" ) } }
					lineHeightTablet= { { value: headLineHeightTablet, label: __( "headLineHeightTablet" ) } }
				/>					
				<hr className="timeline-wp__separator" />
				<TypographyControl
					label={ __( "Date Typography" ) }
					attributes = { props.attributes }
					setAttributes = { setAttributes }
					loadGoogleFonts = { { value: dateLoadGoogleFonts, label: __( "dateLoadGoogleFonts" ) } }
					fontFamily = { { value: dateFontFamily, label: __( "dateFontFamily" ) } }
					fontWeight = { { value: dateFontWeight, label: __( "dateFontWeight" ) } }
					fontSubset = { { value: dateFontSubset, label: __( "dateFontSubset" ) } }
					fontSizeType = { { value: dateFontsizeType, label: __( "dateFontsizeType" ) } }
					fontSize = { { value: dateFontsize, label: __( "dateFontsize" ) } }
					fontSizeMobile = { { value: dateFontsizeMobile, label: __( "dateFontsizeMobile" ) } }
					fontSizeTablet= { { value: dateFontsizeTablet, label: __( "dateFontsizeTablet" ) } }
					lineHeightType = { { value: dateLineHeightType, label: __( "dateLineHeightType" ) } }
					lineHeight = { { value: dateLineHeight, label: __( "dateLineHeight" ) } }
					lineHeightMobile = { { value: dateLineHeightMobile, label: __( "dateLineHeightMobile" ) } }
					lineHeightTablet= { { value: dateLineHeightTablet, label: __( "dateLineHeightTablet" ) } }
				/>
				<hr className="timeline-wp__separator" />
				
				<TypographyControl
					label={ __( "Content Tag" ) }
					attributes = { props.attributes }
					setAttributes = { setAttributes }
					loadGoogleFonts = { { value: subHeadLoadGoogleFonts, label: __( "subHeadLoadGoogleFonts" ) } }
					fontFamily = { { value: subHeadFontFamily, label: __( "subHeadFontFamily" ) } }
					fontWeight = { { value: subHeadFontWeight, label: __( "subHeadFontWeight" ) } }
					fontSubset = { { value: subHeadFontSubset, label: __( "subHeadFontSubset" ) } }
					fontSizeType = { { value: subHeadFontSizeType, label: __( "subHeadFontSizeType" ) } }
					fontSize = { { value: subHeadFontSize, label: __( "subHeadFontSize" ) } }
					fontSizeMobile = { { value: subHeadFontSizeMobile, label: __( "subHeadFontSizeMobile" ) } }
					fontSizeTablet= { { value: subHeadFontSizeTablet, label: __( "subHeadFontSizeTablet" ) } }
					lineHeightType = { { value: subHeadLineHeightType, label: __( "subHeadLineHeightType" ) } }
					lineHeight = { { value: subHeadLineHeight, label: __( "subHeadLineHeight" ) } }
					lineHeightMobile = { { value: subHeadLineHeightMobile, label: __( "subHeadLineHeightMobile" ) } }
					lineHeightTablet= { { value: subHeadLineHeightTablet, label: __( "subHeadLineHeightTablet" ) } }
				/>
			</PanelBody>
			<PanelBody	title={ __( "Color Settings" ) }	initialOpen={ false } >
			</PanelBody>
		</InspectorControls>		
	)


	

	return (
		<Fragment>
			{ content_control }
			<div className={ classnames( className, "twp-timeline-wrapper"   ) } id = { `twp-ctm-${ props.clientId }` } >
				<div  className = { classnames("timeline-content-wrap")  } >
					{ get_content( props ) }	
				</div>
			</div>

		</Fragment>
	)
}
const get_content  = ( props ) => {

	const{
			headingTag,
			design,
			timelinAlignment,
			displayPostDate,
			icon,
			tm_content,
			t_date,
			timelineItem
	} = props.attributes
	console.log(props )
	// Add CSS.
	let hasItems = Array.isArray( tm_content ) && tm_content.length
	let hasDate = Array.isArray( t_date ) && t_date.length
	console.log(timelineItem)
	if ( ! hasItems ) { 
		return(
			<Fragment>
				<Placeholder
					icon="admin-post"
					label={ __( "Timeline" ) }
				>
				</Placeholder>
			</Fragment>
		)
	} else {
		return (
			<div className = { classnames("main-timeline",design )}>
				{
					tm_content.map( ( post, index ) => {
						console.log("Hello")
						return(
							<article className = "timeline"  key={index} >
								<div class="timeline-content">

									<div class="circle">
										<span>{ renderSVG(icon) }</span>
									</div>

									<div class="content">
										<span class="year">2013 - 2014</span>
										<h4 class="title">Web Desginer</h4>
										<p class="description">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce non lectus justo. Nam ultricies laoreet massa sed maximus. Curabitur tristique sagittis scelerisque. Vivamus posuere nisi quis tortor interdum, in finibus risus convallis. Suspendisse efficitur lacus a nulla commodo, sit amet vestibulum nibh.
										</p>
										<div class="icon"><span></span></div>
									</div>
								</div>
							</article>
						)
	
					})
				}	
			</div>
		)
	}

}

export const save = ( props ) => {

	// Setup the attributes.
	const { className, setAttributes, insertBlocksAfter, mergeBlocks, onReplace, attributes: { tm_content, design, headingAlign, separatorHeight, headSpace, separatorSpace, headingColor, subHeadingColor, backgroundColor, separatorColor, separatorFillColor, separatorBg, separatorBorder, borderFocus, headingTag, headFontSizeType, headFontSize, headFontSizeTablet, headFontSizeMobile, headFontFamily, headFontWeight, headFontSubset, headLineHeightType, headLineHeight, headLineHeightTablet, headLineHeightMobile, headLoadGoogleFonts, timelineItem, timelinAlignment, arrowlinAlignment, subHeadFontSizeType, subHeadFontSize, subHeadFontSizeTablet, subHeadFontSizeMobile, subHeadFontFamily, subHeadFontWeight, subHeadFontSubset, subHeadLineHeightType, subHeadLineHeight, subHeadLineHeightTablet, subHeadLineHeightMobile, subHeadLoadGoogleFonts, verticalSpace, horizontalSpace, separatorwidth, borderwidth, connectorBgsize, dateBottomspace, align, icon, iconColor, dateColor, dateFontsizeType, dateFontsize, dateFontsizeTablet, dateFontsizeMobile, dateFontFamily, dateFontWeight, dateFontSubset, dateLineHeightType, dateLineHeight, dateLineHeightTablet, dateLineHeightMobile, dateLoadGoogleFonts, iconSize, borderRadius, bgPadding, block_id, iconFocus, iconBgFocus, t_date, displayPostDate, stack }, } = props

	/*
	* Event to set Image as while adding.
	*/
	
	return (
		<Fragment>			
			<div class="main-timeline">
				<div class="timeline">
					<div class="timeline-content">
						<div class="circle"><span><i class="fa fa-facebook-square"></i></span></div>
						<div class="content">
							<span class="year">2013 - 2014</span>
							<h4 class="title">Web Desginer</h4>
							<p class="description">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce non lectus justo. Nam ultricies laoreet massa sed maximus. Curabitur tristique sagittis scelerisque. Vivamus posuere nisi quis tortor interdum, in finibus risus convallis. Suspendisse efficitur lacus a nulla commodo, sit amet vestibulum nibh.
							</p>
							<div class="icon"><span></span></div>
						</div>
					</div>
				</div>
				<div class="timeline">
					<div class="timeline-content">
						<div class="circle"><span><i class="fa fa-rocket"></i></span></div>
						<div class="content">
							<span class="year">2014 - 2015</span>
							<h4 class="title">Web Developer</h4>
							<p class="description">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce non lectus justo. Nam ultricies laoreet massa sed maximus. Curabitur tristique sagittis scelerisque. Vivamus posuere nisi quis tortor interdum, in finibus risus convallis. Suspendisse efficitur lacus a nulla commodo, sit amet vestibulum nibh.
							</p>
							<div class="icon"><span></span></div>
						</div>
					</div>
				</div>
				<div class="timeline">
					<div class="timeline-content">
						<div class="circle"><span><i class="fa fa-briefcase"></i></span></div>
						<div class="content">
							<span class="year">2015 - 2016</span>
							<h4 class="title">Web Desginer</h4>
							<p class="description">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce non lectus justo. Nam ultricies laoreet massa sed maximus. Curabitur tristique sagittis scelerisque. Vivamus posuere nisi quis tortor interdum, in finibus risus convallis. Suspendisse efficitur lacus a nulla commodo, sit amet vestibulum nibh.
							</p>
							<div class="icon"><span></span></div>
						</div>
					</div>
				</div>
			</div>
			<InspectorControls>
				<PanelBody	title={ __( "General / Design" ) }	initialOpen={ true } >
				</PanelBody>
				<PanelBody	title={ __( "Layout" ) }	initialOpen={ false } >
				</PanelBody>
				<PanelBody	title={ __( "Spacing" ) }	initialOpen={ false } >
				</PanelBody>
				<PanelBody	title={ __( "Timeline Items" ) }	initialOpen={ false } >
				</PanelBody>
				<PanelBody	title={ __( "Color Settings" ) }	initialOpen={ false } >
				</PanelBody>				
			</InspectorControls>
		</Fragment>
	)

}


/**
 * Register: Shortcode Block.
 *
 * Registers a new block provided a unique name and an object defining its
 * behavior. Once registered, the block is made editor as an option to any
 * editor interface where blocks are implemented.
 *
 * @param  Shortcode        	Block name.
 * @param  {Object}   settings 	Block settings.
 * @return {?WPBlock}          	The block, if it has been successfully
 *                             	registered; otherwise `undefined`.
 */

registerBlockType( 'cgb/timeline', {
	// Block name. Block names must be string that contains a namespace prefix. Example: my-plugin/my-custom-block.
	title: __( 'Timeline Instant Bulider' ), // Block title.
	// icon: QuoteIcon, // Block icon from Dasht_date → https://developer.wordpress.org/resource/dasht_date/.
	category: 'timeline', // Block category — Group blocks together based on common traits E.g. common, formatting, layout widgets, embed.
	icon: icon ,
	keywords: [
		__( 'Timeline WP Builder' ),
		__( 'Timeline Example' ),
	],
	attributes,
	edit,
	save,
} );